import retrieve from "./api/managed-records";
export { retrieve };
